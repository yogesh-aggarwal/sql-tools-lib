"""
Attribute extension for SQL-Tools library.
"""

import os

def processId():
    return os.getpid()
