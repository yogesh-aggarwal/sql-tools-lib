
def start():
    from . import analyse
    analyse.start()

if __name__ == "__main__":
    print("Welcome to SQL-Tools CLI tools.\nType help for more information.")
    start()
