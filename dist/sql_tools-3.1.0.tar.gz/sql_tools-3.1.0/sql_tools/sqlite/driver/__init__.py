"""
Sqlite driver for SQL-Tools (sqlite) package.
"""

from sqlite3.dbapi2 import *
