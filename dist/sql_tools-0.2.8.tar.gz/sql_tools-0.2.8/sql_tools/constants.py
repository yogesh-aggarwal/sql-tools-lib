__help__ = """
Please import the module from any file and use it to simplify your work.
For more help contact on GitHub repository https://github.com/yogesh-aggarwal/sql-tools-lib
You can read the full documentation on https://github.com/yogesh-aggarwal/sql-tools-lib/wiki

Thanks for using the package.
"""

__version__ = "SQL-Tools version: 0.2.8"
