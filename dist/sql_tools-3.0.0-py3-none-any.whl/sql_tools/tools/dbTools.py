def sqliteTToMysql(db, table):
    """
    Help in migrating table(s) from sqlite database to MySQL database
    """
    pass


def sqliteDToMysql(db):
    """
    Help in migrating database(s) from sqlite database to MySQL database
    """
    pass


def sqliteTToJson(db, table):
    """
    Help in migrating table(s) from sqlite database to MySQL database
    """
    pass


def sqliteDToJson(db):
    """
    Help in migrating database(s) from sqlite database to MySQL database
    """
    pass


def mysqlTToSqlite(db, table):
    """
    Help in migrating table(s) from MySQL database to sqlite database
    """
    pass


def mysqlDToSqlite(db):
    """
    Help in migrating database(s) from MySQL database to sqlite database
    """
    pass


def mysqlTToJson(db, table):
    """
    Help in migrating table(s) from MySQL database to sqlite database
    """
    pass


def mysqlDToJson(db):
    """
    Help in migrating database(s) from MySQL database to sqlite database
    """
    pass


def JsonTToSqlite(db, table):
    """
    Help in migrating table(s) from MySQL database to sqlite database
    """
    pass


def JsonDToSqlite(db):
    """
    Help in migrating table(s) from MySQL database to sqlite database
    """
    pass


def JsonTToMysql(db, table):
    """
    Help in migrating database(s) from MySQL database to sqlite database
    """
    pass


def JsonDToMysql(db):
    """
    Help in migrating database(s) from MySQL database to sqlite database
    """
    pass
