# A simple python package to help you out in working with simple SQL database related operation.
